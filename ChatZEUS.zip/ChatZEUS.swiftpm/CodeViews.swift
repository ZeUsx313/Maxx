import SwiftUI
import UIKit

// MARK: - جزء واحد من الرسالة (نص/كود)
enum ChatPart: Equatable {
    case text(String)
    case code(lang: String?, body: String)
}

// MARK: - محلّل أسوار الكود الثلاثية ```lang
struct ChatPartsParser {
    static func parse(_ s: String) -> [ChatPart] {
        var parts: [ChatPart] = []
        var remainder = s[...]
        let fence = "```"
        
        while let fenceStart = remainder.range(of: fence) {
            // نص قبل السور
            if fenceStart.lowerBound > remainder.startIndex {
                parts.append(.text(String(remainder[..<fenceStart.lowerBound])))
            }
            // بعد ```: قد تأتي لغة ثم سطر جديد
            let afterFence = fenceStart.upperBound
            guard let lineBreak = remainder[afterFence...].firstIndex(of: "\n") else {
                // لا يوجد سطر جديد => اعتبر الباقي نصًا
                parts.append(.text(String(remainder[afterFence...])))
                return parts
            }
            let maybeLang = remainder[afterFence..<lineBreak].trimmingCharacters(in: .whitespacesAndNewlines)
            let lang: String? = maybeLang.isEmpty ? nil : String(maybeLang)
            
            // ابحث عن السور الختامي
            let afterHeader = remainder.index(after: lineBreak)
            if let fenceEnd = remainder[afterHeader...].range(of: fence) {
                let codeBody = String(remainder[afterHeader..<fenceEnd.lowerBound])
                parts.append(.code(lang: lang, body: codeBody))
                remainder = remainder[fenceEnd.upperBound...]
            } else {
                // لا سور إغلاق -> اعتبره نصًا
                parts.append(.text(String(remainder[fenceStart.lowerBound...])))
                return parts
            }
        }
        if !remainder.isEmpty {
            parts.append(.text(String(remainder)))
        }
        return parts
    }
}

// MARK: - زر نسخ يتبدّل نصّه مؤقتًا
struct CopyButton: View {
    let textToCopy: String
    @State private var copied = false
    
    var body: some View {
        Button {
            UIPasteboard.general.string = textToCopy
            withAnimation(.spring()) { copied = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation(.easeOut) { copied = false }
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: copied ? "checkmark.circle.fill" : "doc.on.doc")
                Text(copied ? "تم النسخ" : "نسخ")
            }
            .font(.callout)
            .padding(.horizontal, 10).padding(.vertical, 6)
            // تم حذف .background(.ultraThinMaterial, in: Capsule())
        }
        .animation(.default, value: copied)
    }
}

// MARK: - جسم رسالة دردشة (نص + كتل كود)
struct ChatMessageBodyView: View {
    let content: String
    let fontSize: Double
    
    // نص ماركداون مبسّط (غامق/مائل/inline code)
    private func richText(_ s: String) -> AttributedString {
        var opts = AttributedString.MarkdownParsingOptions()
        opts.interpretedSyntax = .inlineOnly
        opts.allowsExtendedAttributes = true
        
        // معالجة العناوين والقوائم والجداول وإزالة رموز الماركداون من النص
        var processedText = s
        let lines = s.components(separatedBy: .newlines)
        var processedLines: [String] = []
        var isInTable = false
        var tableHeaderProcessed = false
        
        for (index, line) in lines.enumerated() {
            let trimmedLine = line.trimmingCharacters(in: .whitespaces)
            var processedLine = line
            
            // التحقق من وجود جدول (يحتوي على |)
            if trimmedLine.contains("|") && !trimmedLine.isEmpty {
                isInTable = true
                
                // التحقق من سطر الفاصل (---|---) وتجاهله
                if trimmedLine.contains("-") && trimmedLine.replacingOccurrences(of: "|", with: "").replacingOccurrences(of: "-", with: "").replacingOccurrences(of: " ", with: "").isEmpty {
                    processedLine = "" // إزالة سطر الفاصل
                    tableHeaderProcessed = true
                } else {
                    // معالجة سطر الجدول العادي
                    let cells = trimmedLine.components(separatedBy: "|").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
                    
                    if !tableHeaderProcessed {
                        // سطر العنوان: إضافة تنسيق خاص
                        processedLine = "┌" + String(repeating: "─", count: 50) + "┐"
                        processedLine += "\n│ " + cells.joined(separator: " │ ") + " │"
                        processedLine += "\n├" + String(repeating: "─", count: 50) + "┤"
                    } else {
                        // سطر البيانات العادي
                        processedLine = "│ " + cells.joined(separator: " │ ") + " │"
                    }
                }
            } else {
                // إذا كنا خارج الجدول الآن، أضف خط الإغلاق
                if isInTable {
                    processedLines.append("└" + String(repeating: "─", count: 50) + "┘")
                    isInTable = false
                    tableHeaderProcessed = false
                }
                
                // معالجة العناصر الأخرى
                // إزالة رموز # من العناوين
                if trimmedLine.hasPrefix("#### ") {
                    processedLine = line.replacingOccurrences(of: "#### ", with: "")
                } else if trimmedLine.hasPrefix("### ") {
                    processedLine = line.replacingOccurrences(of: "### ", with: "")
                } else if trimmedLine.hasPrefix("## ") {
                    processedLine = line.replacingOccurrences(of: "## ", with: "")
                } else if trimmedLine.hasPrefix("# ") {
                    processedLine = line.replacingOccurrences(of: "# ", with: "")
                }
                // إزالة رموز * من القوائم النقطية واستبدالها برمز نقطة
                else if trimmedLine.hasPrefix("* ") {
                    let bulletText = String(trimmedLine.dropFirst(2))
                    let indentation = String(repeating: " ", count: line.count - line.trimmingCharacters(in: .whitespaces).count)
                    processedLine = indentation + "• " + bulletText
                }
            }
            
            if !processedLine.isEmpty {
                processedLines.append(processedLine)
            }
        }
        
        // إغلاق الجدول إذا انتهى النص وما زال الجدول مفتوحاً
        if isInTable {
            processedLines.append("└" + String(repeating: "─", count: 50) + "┘")
        }
        
        processedText = processedLines.joined(separator: "\n")
        
        // محاولة معالجة الماركداون
        do {
            var result = try AttributedString(markdown: processedText, options: opts)
            
            // تطبيق تنسيق العناوين والقوائم والجداول يدوياً على النص المنظف
            let cleanLines = processedText.components(separatedBy: .newlines)
            
            for (index, line) in lines.enumerated() {
                let trimmedLine = line.trimmingCharacters(in: .whitespaces)
                
                if index < cleanLines.count {
                    let cleanLine = cleanLines[index].trimmingCharacters(in: .whitespaces)
                    
                    // العنوان الرئيسي #
                    if trimmedLine.hasPrefix("# ") {
                        if let range = result.range(of: cleanLine, locale: nil) {
                            result[range].font = .system(size: 24, weight: .bold)
                            result[range].foregroundColor = .white
                        }
                    }
                    // العنوان الثانوي ##
                    else if trimmedLine.hasPrefix("## ") {
                        if let range = result.range(of: cleanLine, locale: nil) {
                            result[range].font = .system(size: 20, weight: .bold)
                            result[range].foregroundColor = .white
                        }
                    }
                    // العنوان الفرعي ###
                    else if trimmedLine.hasPrefix("### ") {
                        if let range = result.range(of: cleanLine, locale: nil) {
                            result[range].font = .system(size: 18, weight: .semibold)
                            result[range].foregroundColor = .white
                        }
                    }
                    // العنوان الفرعي الصغير ####
                    else if trimmedLine.hasPrefix("#### ") {
                        if let range = result.range(of: cleanLine, locale: nil) {
                            result[range].font = .system(size: 16, weight: .semibold)
                            result[range].foregroundColor = .white
                        }
                    }
                    // القائمة النقطية *
                    else if trimmedLine.hasPrefix("* ") {
                        if let bulletRange = result.range(of: "•", locale: nil) {
                            result[bulletRange].foregroundColor = .white
                            result[bulletRange].font = .system(size: 16, weight: .medium)
                        }
                        let bulletText = String(trimmedLine.dropFirst(2))
                        if let textRange = result.range(of: bulletText, locale: nil) {
                            result[textRange].foregroundColor = .white
                        }
                    }
                }
            }
            
            // تنسيق رموز الجدول
            let tableChars = ["┌", "┐", "├", "┤", "└", "┘", "─", "│"]
            for char in tableChars {
                var searchRange = result.startIndex..<result.endIndex
                while let range = result[searchRange].range(of: char) {
                    result[range].foregroundColor = .gray
                    result[range].font = .system(size: 14, weight: .medium, design: .monospaced)
                    searchRange = range.upperBound..<result.endIndex
                }
            }
            
            return result
        } catch {
            // في حالة فشل المعالجة، استخدم النص المنظف
            return AttributedString(processedText)
        }
    }
    
    var body: some View {
        let parts = ChatPartsParser.parse(content)
        
        VStack(alignment: .leading, spacing: 10) {        // في RTL: leading = يمين
            ForEach(Array(parts.enumerated()), id: \.offset) { _, p in
                switch p {
                case .text(let s):
                    Text(richText(s))
                        .font(.system(size: fontSize))
                        .foregroundColor(.white)
                        .textSelection(.enabled)
                    
                case .code(let lang, let body):
                    // يستخدم SimpleSyntaxHighlighter داخل CodeBlockView
                    CodeBlockView(code: body, language: normalize(lang))
                        .frame(maxWidth: .infinity, alignment: .leading) // ✅ الآن ياخذ كامل عرض الشاشة
                }
            }
        }
    }
    
    /// توحيد/تطبيع أسماء اللغات لعرض الشارة الصحيحة.
    /// - إن لم تُذكر لغة نعيد "code" كي تُعرض شارة عامة.
    /// - المرادفات تُحوّل لاسم موحّد (javascript, typescript, bash, css, …).
    private func normalize(_ lang: String?) -> String {
        guard let raw0 = lang?.trimmingCharacters(in: .whitespacesAndNewlines),
              !raw0.isEmpty else {
            return "code" // لا لغة محددة
        }
        let raw = raw0.lowercased()
        
        switch raw {
            // أساسيات الويب
        case "js", "javascript", "node", "nodejs": return "javascript"
        case "ts", "typescript": return "typescript"
        case "html", "htm": return "html"
        case "css": return "css"
        case "scss", "sass": return "scss"
        case "less": return "less"
            
            // بايثون والأسرة
        case "py", "python": return "python"
            
            // شِل
        case "sh", "bash", "zsh", "shell": return "bash"
            
            // تكوينات وبيانات
        case "json": return "json"
        case "yaml", "yml": return "yaml"
        case "toml": return "toml"
        case "ini": return "ini"
        case "xml": return "xml"
        case "md", "markdown": return "markdown"
            
            // قواعد بيانات
        case "sql", "postgres", "postgresql", "mysql", "sqlite", "mssql": return "sql"
            
            // لغات سي وعائلتها
        case "c": return "c"
        case "cpp", "c++", "cxx": return "cpp"
        case "cs", "csharp", "c#": return "csharp"
        case "objective-c", "objc", "objectivec": return "objective-c"
            
            // أخرى شائعة
        case "swift": return "swift"
        case "java": return "java"
        case "kotlin", "kt": return "kotlin"
        case "go", "golang": return "go"
        case "rs", "rust": return "rust"
        case "php": return "php"
        case "rb", "ruby": return "ruby"
        case "dart": return "dart"
        case "r": return "r"
        case "scala": return "scala"
        case "perl", "pl": return "perl"
        case "matlab": return "matlab"
        case "powershell", "ps", "ps1": return "powershell"
        case "lua": return "lua"
        case "haskell", "hs": return "haskell"
        case "elixir", "ex", "exs": return "elixir"
        case "clojure", "clj", "cljs": return "clojure"
        case "groovy": return "groovy"
        case "dart": return "dart"
            
            // أدوات/ملفات بناء
        case "dockerfile", "docker": return "dockerfile"
        case "makefile", "make": return "makefile"
        case "gradle": return "gradle"
        case "cmake": return "cmake"
            
            // إطار عام: إن كانت لغة غير معروفة لدينا، أعِدها كما هي بدون إجبارها على swift
        default:
            return raw
        }
    }
}
