import SwiftUI
import Highlightr

// 🔹 ملوّن متقدم باستخدام مكتبة Highlightr يدعم +185 لغة برمجية
struct HighlightrSyntaxHighlighter {
    private let highlightr = Highlightr()
    
    init() {
        // تعيين نمط التلوين المظلم (يمكنك تغييره)
        highlightr?.setTheme(to: "atom-one-dark")
    }
    
    /// يلوّن `code` بحسب `lang` باستخدام مكتبة Highlightr
    func highlight(_ code: String, lang: String?) -> AttributedString {
        guard let highlightr = highlightr else {
            // في حالة فشل تحميل المكتبة، عرض النص العادي
            var fallback = AttributedString(code)
            fallback.foregroundColor = .white
            fallback.font = .system(size: 14, design: .monospaced)
            return fallback
        }
        
        // تنظيف وتوحيد اسم اللغة
        let normalizedLang = normalize(lang)
        
        // محاولة تلوين الكود
        if let highlightedNSString = highlightr.highlight(code, as: normalizedLang) {
            // تحويل NSAttributedString إلى AttributedString
            do {
                return try AttributedString(highlightedNSString, including: \.uiKit)
            } catch {
                print("❌ فشل تحويل NSAttributedString إلى AttributedString: \(error)")
            }
        }
        
        // في حالة الفشل، عرض النص العادي مع تنسيق أساسي
        var fallback = AttributedString(code)
        fallback.foregroundColor = .white
        fallback.font = .system(size: 14, design: .monospaced)
        return fallback
    }
    
    /// توحيد/تطبيع أسماء اللغات لتتوافق مع Highlight.js
    private func normalize(_ lang: String?) -> String? {
        guard let raw0 = lang?.trimmingCharacters(in: .whitespacesAndNewlines),
              !raw0.isEmpty else {
            return nil // تلقائي - Highlightr سيحدد اللغة تلقائياً
        }
        
        let raw = raw0.lowercased()
        
        switch raw {
            // أساسيات الويب
        case "js", "node", "nodejs": return "javascript"
        case "ts": return "typescript"
        case "htm": return "html"
        case "scss", "sass": return "scss"
        case "less": return "less"
            
            // بايثون
        case "py": return "python"
            
            // شِل
        case "sh", "zsh", "shell": return "bash"
            
            // تكوينات وبيانات
        case "yml": return "yaml"
        case "md": return "markdown"
            
            // قواعد بيانات
        case "postgres", "postgresql", "mysql", "sqlite", "mssql": return "sql"
            
            // لغات سي وعائلتها
        case "cpp", "c++", "cxx": return "cpp"
        case "cs", "csharp", "c#": return "csharp"
        case "objective-c", "objc", "objectivec": return "objectivec"
            
            // أخرى شائعة
        case "kt": return "kotlin"
        case "golang": return "go"
        case "rs": return "rust"
        case "rb": return "ruby"
        case "pl": return "perl"
        case "ps", "ps1": return "powershell"
        case "hs": return "haskell"
        case "ex", "exs": return "elixir"
        case "clj", "cljs": return "clojure"
            
            // أدوات/ملفات بناء
        case "docker": return "dockerfile"
        case "make": return "makefile"
            
            // اللغات المدعومة مباشرة بأسمائها الصحيحة
        default:
            return raw
        }
    }
}



// 🔹 صندوق الكود يستخدم Highlightr
// **تم نقل هذا الـ struct إلى النهاية ليعمل بشكل صحيح**
struct CodeBlockView: View {
    let code: String
    let language: String?
    private let highlighter = HighlightrSyntaxHighlighter()
    
    var body: some View {
        VStack(spacing: 0) {
            // شريط العنوان مع زر النسخ ولغة البرمجة
            HStack {
                CopyButton(textToCopy: code)
                Spacer()
                Text(displayLanguage(language))
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color(.black))
            
            // المحتوى الرئيسي للكود
            ScrollView(.horizontal) {
                ScrollView {
                    Text(highlighter.highlight(code, lang: language))
                        .multilineTextAlignment(.leading)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(12)
                }
            }
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.secondarySystemBackground).opacity(0.15))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(.white.opacity(0.08))
            )
        }
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .environment(\.layoutDirection, .leftToRight) // الكود LTR
    }
    
    /// عرض اسم اللغة في شريط العنوان
    private func displayLanguage(_ lang: String?) -> String {
        guard let lang = lang?.trimmingCharacters(in: .whitespacesAndNewlines),
              !lang.isEmpty else {
            return "code"
        }
        
        // عرض اسم أجمل للغات الشائعة
        switch lang.lowercased() {
        case "js", "javascript": return "JavaScript"
        case "ts", "typescript": return "TypeScript"
        case "py", "python": return "Python"
        case "swift": return "Swift"
        case "html", "htm": return "HTML"
        case "css": return "CSS"
        case "scss", "sass": return "SCSS"
        case "json": return "JSON"
        case "yaml", "yml": return "YAML"
        case "xml": return "XML"
        case "sql": return "SQL"
        case "bash", "sh", "shell": return "Shell"
        case "java": return "Java"
        case "kotlin", "kt": return "Kotlin"
        case "go", "golang": return "Go"
        case "rust", "rs": return "Rust"
        case "cpp", "c++": return "C++"
        case "c": return "C"
        case "csharp", "cs", "c#": return "C#"
        case "php": return "PHP"
        case "ruby", "rb": return "Ruby"
        case "dart": return "Dart"
        case "r": return "R"
        case "dockerfile", "docker": return "Dockerfile"
        default:
            return lang.capitalized
        }

    }
}

